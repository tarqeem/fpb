! function (t) {
    var e = {};

    function n(r) {
        if (e[r]) return e[r].exports;
        var o = e[r] = {
            i: r,
            l: !1,
            exports: {}
        };
        return t[r].call(o.exports, o, o.exports, n), o.l = !0, o.exports
    }
    n.m = t, n.c = e, n.d = function (t, e, r) {
        n.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: r
        })
    }, n.r = function (t) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }, n.t = function (t, e) {
        if (1 & e && (t = n(t)), 8 & e) return t;
        if (4 & e && "object" == typeof t && t && t.__esModule) return t;
        var r = Object.create(null);
        if (n.r(r), Object.defineProperty(r, "default", {
                enumerable: !0,
                value: t
            }), 2 & e && "string" != typeof t)
            for (var o in t) n.d(r, o, function (e) {
                return t[e]
            }.bind(null, o));
        return r
    }, n.n = function (t) {
        var e = t && t.__esModule ? function () {
            return t.default
        } : function () {
            return t
        };
        return n.d(e, "a", e), e
    }, n.o = function (t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }, n.p = "", n(n.s = 0)
}([function (t, e, n) {
    if (globalThis.chrome && chrome.storage) {
        n(12);
        var r = chrome.storage.sync,
            o = chrome.runtime.connect({
                name: "fpsbg"
            }),
            a = function (t) {
                var e = t.detail;
                return chrome.storage.local.set(e)
            },
            i = function (t) {
                var e = t.detail;
                return o.postMessage(e)
            },
            u = function (t) {
                return r.get(["v", "s", "g", "w"], (function (t) {
                    if (null == t.g) r.set({
                        v: 1039,
                        s: Math.random(),
                        g: Math.random().toString(36).substr(2)
                    });
                    else {
                        if ((2048 | t.v) == t.v && (o = t.w, u = window.location.hostname, new RegExp("^(" + o.replace(/\*/g, ".*").replace(/[\n,]+/g, "|") + ")$").test(u))) return;
                        window.removeEventListener("clogs", a), window.addEventListener("clogs", a), window.removeEventListener("ncache", i), window.addEventListener("ncache", i);
                        var e = JSON.stringify(t),
                            n = document.createElement("script");
                        n.src = chrome.runtime.getURL("cts.js"), n.setAttribute("detail", e), document.documentElement.appendChild(n).parentNode.removeChild(n)
                    }

                    if ((4096 | t.v) == t.v) {
                        // console.log('generating new seed');
                        r.set({
                            v: t.v ^ 4096,
                            s: Math.random()
                        });
                    }

                    var o, u
                }))
            };
        u(), chrome.storage.onChanged.addListener((function (t) {
            return t.v && u()
        }))

    } else ! function (t) {
        var e = JSON.parse(t),
            n = e.g,
            r = e.g.substr(1),
            o = e.g.substr(2);
        window[n] ? e = Object.assign(window[n], e) : window[n] = e;
        var a = function (t, n) {
            return n.forEach((function (n) {
                return e[n] = (t | e.v) == e.v ? t : 0
            }))
        };

        if (a(1, ["toDataURL", "toBlob", "getImageData", "measureText", "convertToBlob"]), a(2, ["readPixels", "getExtension", "getParameter"]), a(4, ["getChannelData", "getFloatFrequencyData"]), a(8, ["offsetWidth", "offsetHeight"]), a(16, ["getClientRects"]), a(32, ["enumerateDevices", "MediaStreamTrack", "RTCPeerConnection", "RTCSessionDescription", "webkitMediaStreamTrack", "webkitRTCPeerConnection", "webkitRTCSessionDescription"]), a(64, ["getBattery", "getGamepads", "getVRDisplays", "screen", "platform", "language", "languages"]), a(128, ["getTimezoneOffset", "resolvedOptions"]), a(256, ["logs"]), a(1024, ["nocache"]), a(2048, ["wlist"]), !window[r]) {
            var i = function (t, e, n) {
                    var r = {};
                    r[e] = n, window.dispatchEvent(new CustomEvent(t, {
                        detail: r
                    }))
                },
                u = function (t) {
                    // console.log(e.s);
                    return Math.floor(e.s * t)
                },
                c = function () {
                    return e.i % e.c == 0 && (e.i = 1, e.n.push(e.c = e.n.shift())), e.r % e.c == e.i++ ? 1 : 0
                };
            Object.assign(e, {
                i: 0,
                c: 7,
                n: [7, 11, 13, 17, 19, 2053],
                r: u(1e6)
            });
            var s = function (t) {
                if (t[r]) return t;
                var n = function (t, n) {
                        var r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : void 0,
                            o = function (n, r) {
                                var o = t[n];
                                Object.defineProperty(t, n, {
                                    get: function () {
                                        return 0 === e[n] && o ? o.bind(this) : r
                                    }
                                })
                            };
                        t && ("string" == typeof n ? o(n, r) : n instanceof Array ? n.forEach((function (t) {
                            return o(t, r)
                        })) : Object.keys(n).forEach((function (t) {
                            return o(t, n[t])
                        })))
                    },
                    a = function (t, n) {
                        return Object.keys(n).forEach((function (r) {
                            var o = t[r];
                            Object.defineProperty(t, r, {
                                get: function () {
                                    return 0 !== e[r] ? n[r] : o
                                }
                            })
                        }))
                    },
                    s = function (n) {
                        try {
                            n(t)
                        } catch (t) {
                            e.debug && console.error(t)
                        }
                    };
                return s((function (t) {
                    var r = t.WebGLRenderingContext.prototype,
                        o = r.getParameter,
                        a = r.getExtension,
                        i = r.readPixels,
                        c = null,
                        s = null;
                    n(t.WebGLRenderingContext.prototype, {
                        readPixels: function (t, n, r, o, a, u, c, s) {
                            var l = e.s + 1,
                                f = Math.max(1, parseInt(r / 11)),
                                p = Math.max(1, parseInt(o / 11));
                            if (i.apply(this, arguments), c instanceof Uint8Array)
                                for (var d = 0; d < o; d += p)
                                    for (var g = 0; g < r; g += f) c[4 * r * d + 4 * g] *= l
                        },
                        getParameter: function (e) {
                            return e == t.WebGLRenderingContext.RENDERER || e == c ? "Intel HD Graphics " + (u(8e3) + 500) + " OpenGL Engine" : e == t.WebGLRenderingContext.VENDOR || e == s ? "Google Inc." : o.apply(this, arguments)
                        },
                        getExtension: function (t) {
                            var e = a.apply(this, arguments);
                            return "WEBGL_debug_renderer_info" == t && (c = e.UNMASKED_RENDERER_WEBGL, s = e.UNMASKED_VENDOR_WEBGL), e
                        }
                    })
                })), s((function (t) {
                    var r = t.WebGL2RenderingContext.prototype,
                        o = r.getParameter,
                        a = r.getExtension,
                        i = r.readPixels,
                        c = null,
                        s = null;
                    n(t.WebGL2RenderingContext.prototype, {
                        readPixels: function (t, n, r, o, a, u, c, s) {
                            var l = e.s + 1,
                                f = Math.max(1, parseInt(r / 11)),
                                p = Math.max(1, parseInt(o / 11));
                            if (i.apply(this, arguments), c instanceof Uint8Array)
                                for (var d = 0; d < o; d += p)
                                    for (var g = 0; g < r; g += f) c[4 * r * d + 4 * g] *= l
                        },
                        getParameter: function (e) {
                            return e == t.WebGL2RenderingContext.RENDERER || e == c ? "Intel HD Graphics " + (u(8e3) + 500) + " OpenGL Engine" : e == t.WebGL2RenderingContext.VENDOR || e == s ? "Google Inc." : o.apply(this, arguments)
                        },
                        getExtension: function (t) {
                            var e = a.apply(this, arguments);
                            return "WEBGL_debug_renderer_info" == t && (c = e.UNMASKED_RENDERER_WEBGL, s = e.UNMASKED_VENDOR_WEBGL), e
                        }
                    })
                })), s((function (t) {
                    var r = t.CanvasRenderingContext2D.prototype,
                        a = r.measureText,
                        u = r.getImageData;
                    n(t.CanvasRenderingContext2D.prototype, {
                        measureText: function () {
                            var n = a.apply(this, arguments),
                                r = n.actualBoundingBoxAscent,
                                o = n.actualBoundingBoxDescent,
                                i = n.actualBoundingBoxLeft,
                                u = n.actualBoundingBoxRight,
                                c = n.fontBoundingBoxAscent,
                                s = n.fontBoundingBoxDescent,
                                l = n.width;
                            return l += e.s / 1e6, {
                                __proto__: t.TextMetrics.prototype,
                                actualBoundingBoxAscent: r,
                                actualBoundingBoxDescent: o,
                                actualBoundingBoxLeft: i,
                                actualBoundingBoxRight: u,
                                fontBoundingBoxAscent: c,
                                fontBoundingBoxDescent: s,
                                width: l
                            }
                        },
                        getImageData: function (t, n, r, o, a) {
                            for (var i = e.s + 1, c = Math.max(1, parseInt(r / 11)), s = Math.max(1, parseInt(o / 11)), l = u.apply(this, arguments), f = 0; f < o; f += s)
                                for (var p = 0; p < r; p += c) l.data[4 * r * f + 4 * p] *= i;
                            return l
                        }
                    });
                    var c = t.HTMLCanvasElement.prototype,
                        s = c.toDataURL,
                        l = c.toBlob,
                        f = function (t) {
                            if (t[o]) return t[o];
                            e.logs && i("clogs", location.host, s.apply(t)), t[o] = t.cloneNode(!0);
                            var n = t.getContext("2d").getImageData(0, 0, t.width, t.height);
                            return t[o].getContext("2d").putImageData(n, 0, 0), t[o]
                        };
                    n(t.HTMLCanvasElement.prototype, {
                        toDataURL: function () {
                            return s.apply(f(this), arguments)
                        },
                        toBlob: function () {
                            return l.apply(f(this), arguments)
                        }
                    });
                    var p = t.OffscreenCanvas.prototype.convertToBlob,
                        d = function (e) {
                            if (e[o]) return e[o];
                            var n = t.document.createElement("canvas");
                            n.width = e.width, n.height = e.height;
                            var r = n.getContext("2d");
                            r.drawImage(e.transferToImageBitmap(), 0, 0);
                            var a = r.getImageData(0, 0, n.width, n.height);
                            return e[o] = new t.OffscreenCanvas(e.width, e.height), e[o].getContext("2d").putImageData(a, 0, 0), e[o]
                        };
                    n(t.OffscreenCanvas.prototype, {
                        convertToBlob: function () {
                            return p.apply(d(this), arguments)
                        }
                    })
                })), s((function (t) {
                    var r = null,
                        o = t.AudioBuffer.prototype.getChannelData;
                    n(t.AudioBuffer.prototype, {
                        getChannelData: function () {
                            var t = o.apply(this, arguments);
                            if (r == t) return r;
                            r = t;
                            for (var n = 0; n < r.length; n += 88) {
                                var a = u(n);
                                r[a] = (r[a] + e.s) / 2
                            }
                            return r
                        }
                    })
                })), s((function (t) {
                    var r = t.AnalyserNode.prototype.getFloatFrequencyData;
                    n(t.AnalyserNode.prototype, {
                        getFloatFrequencyData: function () {
                            for (var t = r.apply(this, arguments), n = 0; n < arguments[0].length; n += 88) {
                                var o = u(n);
                                arguments[o] = (arguments[o] + e.s) / 2
                            }
                            return t
                        }
                    })
                })), s((function (t) {
                    return n = t.HTMLElement.prototype, r = {
                        offsetWidth: function () {
                            return Math.floor(this.getBoundingClientRect().width) + c()
                        },
                        offsetHeight: function () {
                            return Math.floor(this.getBoundingClientRect().height) + c()
                        }
                    }, Object.keys(r).forEach((function (t) {
                        var o = n.__lookupGetter__(t);
                        Object.defineProperty(n, t, {
                            get: function () {
                                return (0 !== e[t] ? r[t] : o).apply(this, arguments)
                            }
                        })
                    }));
                    var n, r
                })), s((function (t) {
                    return n(t.Element.prototype, "getClientRects", (function () {
                        return {
                            0: {
                                x: 0,
                                y: 0,
                                top: 0,
                                bottom: u(500),
                                left: 0,
                                right: u(400),
                                height: u(500),
                                width: u(400),
                                __proto__: t.DOMRect.prototype
                            },
                            length: 1,
                            __proto__: t.DOMRectList.prototype
                        }
                    }))
                })), s((function (t) {
                    return a(t, {
                        screen: {
                            availLeft: 0,
                            availTop: 0,
                            availWidth: 1024,
                            availHeight: 768,
                            width: 1024,
                            height: 768,
                            colorDepth: 16,
                            pixelDepth: 16,
                            __proto__: t.Screen.prototype,
                            orientation: {
                                angle: 0,
                                type: "landscape-primary",
                                onchange: null,
                                __proto__: t.ScreenOrientation.prototype
                            }
                        }
                    })
                })), s((function (t) {
                    return n(t.navigator, ["getBattery", "getGamepads", "getVRDisplays"])
                })), s((function (t) {
                    return a(t.navigator, {
                        platform: "Win32",
                        language: "en-US",
                        languages: ["en-US"]
                    })
                })), s((function (t) {
                    var e = t.navigator.mediaDevices.enumerateDevices;
                    n(t.navigator.mediaDevices, {
                        enumerateDevices: function () {
                            return e.apply(this, arguments).then((function (e) {
                                return e.push({
                                    deviceId: "default",
                                    groupId: "n/a",
                                    kind: "audiooutput",
                                    label: "FPS-Audio " + u(400),
                                    __proto__: t.MediaDeviceInfo.prototype
                                }), e
                            }))
                        }
                    })
                })), s((function (t) {
                    return n(t, ["MediaStreamTrack", "RTCPeerConnection", "RTCSessionDescription", "webkitMediaStreamTrack", "webkitRTCPeerConnection", "webkitRTCSessionDescription"])
                })), s((function (t) {
                    return n(t.Intl.DateTimeFormat.prototype, "resolvedOptions", (function () {
                        return {
                            calendar: "gregory",
                            day: "numeric",
                            locale: "en-US",
                            month: "numeric",
                            numberingSystem: "latn",
                            timeZone: "UTC",
                            year: "numeric"
                        }
                    }))
                })), s((function (t) {
                    return n(t.Date.prototype, "getTimezoneOffset", (function () {
                        return [720, 660, 600, 570, 540, 480, 420, 360, 300, 240, 210, 180, 120, 60, 0, -60, -120, -180, -210, -240, -270, -300, -330, -345, -360, -390, -420, -480, -510, -525, -540, -570, -600, -630, -660, -720, -765, -780, -840][u(39)]
                    }))
                })), t[r] = !0, t
            };
            s(window);
            var l = window.HTMLIFrameElement.prototype.__lookupGetter__("contentWindow"),
                f = window.HTMLIFrameElement.prototype.__lookupGetter__("contentDocument");
            Object.defineProperties(window.HTMLIFrameElement.prototype, {
                contentWindow: {
                    get: function () {
                        try {
                            return s(l.apply(this, arguments))
                        } catch (t) {
                            return l.apply(this, arguments)
                        }
                    }
                },
                contentDocument: {
                    get: function () {
                        try {
                            s(l.apply(this, arguments))
                        } finally {
                            return f.apply(this, arguments)
                        }
                    }
                }
            }), e.nocache && i("ncache", "origin", location.origin)
        }
    }(document.currentScript.getAttribute("detail"))
}, , , , , , , , , , function (t, e) {
    t.exports = function (t, e) {
        (null == e || e > t.length) && (e = t.length);
        for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
        return r
    }, t.exports.__esModule = !0, t.exports.default = t.exports
}, function (t, e, n) {
    var r = n(13),
        o = n(14),
        a = n(15),
        i = n(16);
    t.exports = function (t) {
        return r(t) || o(t) || a(t) || i()
    }, t.exports.__esModule = !0, t.exports.default = t.exports
}, function (t, e, n) {
    "use strict";
    n.r(e);
    var r = n(11),
        o = n.n(r);

    function a(t, e) {
        var n = "undefined" != typeof Symbol && t[Symbol.iterator] || t["@@iterator"];
        if (!n) {
            if (Array.isArray(t) || (n = function (t, e) {
                    if (!t) return;
                    if ("string" == typeof t) return i(t, e);
                    var n = Object.prototype.toString.call(t).slice(8, -1);
                    "Object" === n && t.constructor && (n = t.constructor.name);
                    if ("Map" === n || "Set" === n) return Array.from(t);
                    if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return i(t, e)
                }(t)) || e && t && "number" == typeof t.length) {
                n && (t = n);
                var r = 0,
                    o = function () {};
                return {
                    s: o,
                    n: function () {
                        return r >= t.length ? {
                            done: !0
                        } : {
                            done: !1,
                            value: t[r++]
                        }
                    },
                    e: function (t) {
                        throw t
                    },
                    f: o
                }
            }
            throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }
        var a, u = !0,
            c = !1;
        return {
            s: function () {
                n = n.call(t)
            },
            n: function () {
                var t = n.next();
                return u = t.done, t
            },
            e: function (t) {
                c = !0, a = t
            },
            f: function () {
                try {
                    u || null == n.return || n.return()
                } finally {
                    if (c) throw a
                }
            }
        }
    }

    function i(t, e) {
        (null == e || e > t.length) && (e = t.length);
        for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
        return r
    }
    chrome.runtime.sendMessage("get-config", (function (t) {
        var e, n = document.location + "";
        e = function () {
            function e() {
                var e, r = a(t);
                try {
                    var i = function () {
                        var t = e.value;
                        new RegExp(t.pattern, "gi").test(n) && o()(document.querySelectorAll(t.selector)).filter((function (t) {
                            return !t.hasAttribute("skip-element")
                        })).forEach((function (e) {
                            var n, r = e.style.display;
                            e.style.display = "none", e.setAttribute("skip-element", !0), fetch((n = t.url, n.replace(/{[\w.]+}/, (function (t) {
                                var e = t.substr(1, t.length - 2).split(".").reduce((function (t, e) {
                                    return t[e]
                                }), window);
                                return encodeURIComponent(e)
                            })))).then((function (t) {
                                return t.text()
                            })).then((function (n) {
                                var r = n.trim();
                                r && (e[t.attr] = r)
                            })).catch((function () {})).then((function () {
                                return e.style.display = r
                            }))
                        }))
                    };
                    for (r.s(); !(e = r.n()).done;) i()
                } catch (t) {
                    r.e(t)
                } finally {
                    r.f()
                }
            }
            e(), new MutationObserver((function () {
                return e()
            })).observe(document.body, {
                childList: !0,
                subtree: !0
            })
        }, "loading" === document.readyState ? document.addEventListener("DOMContentLoaded", e) : e()
    }))
}, function (t, e, n) {
    var r = n(10);
    t.exports = function (t) {
        if (Array.isArray(t)) return r(t)
    }, t.exports.__esModule = !0, t.exports.default = t.exports
}, function (t, e) {
    t.exports = function (t) {
        if ("undefined" != typeof Symbol && null != t[Symbol.iterator] || null != t["@@iterator"]) return Array.from(t)
    }, t.exports.__esModule = !0, t.exports.default = t.exports
}, function (t, e, n) {
    var r = n(10);
    t.exports = function (t, e) {
        if (t) {
            if ("string" == typeof t) return r(t, e);
            var n = Object.prototype.toString.call(t).slice(8, -1);
            return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(t) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? r(t, e) : void 0
        }
    }, t.exports.__esModule = !0, t.exports.default = t.exports
}, function (t, e) {
    t.exports = function () {
        throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
    }, t.exports.__esModule = !0, t.exports.default = t.exports
}]);