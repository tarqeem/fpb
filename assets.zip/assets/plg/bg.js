! function (t) {
    var e = {};

    function r(n) {
        if (e[n]) return e[n].exports;
        var o = e[n] = {
            i: n,
            l: !1,
            exports: {}
        };
        return t[n].call(o.exports, o, o.exports, r), o.l = !0, o.exports
    }
    r.m = t, r.c = e, r.d = function (t, e, n) {
        r.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: n
        })
    }, r.r = function (t) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }, r.t = function (t, e) {
        if (1 & e && (t = r(t)), 8 & e) return t;
        if (4 & e && "object" == typeof t && t && t.__esModule) return t;
        var n = Object.create(null);
        if (r.r(n), Object.defineProperty(n, "default", {
                enumerable: !0,
                value: t
            }), 2 & e && "string" != typeof t)
            for (var o in t) r.d(n, o, function (e) {
                return t[e]
            }.bind(null, o));
        return n
    }, r.n = function (t) {
        var e = t && t.__esModule ? function () {
            return t.default
        } : function () {
            return t
        };
        return r.d(e, "a", e), e
    }, r.o = function (t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }, r.p = "", r(r.s = 9)
}([, , , function (t, e, r) {
    var n = r(7)();
    t.exports = n;
    try {
        regeneratorRuntime = n
    } catch (t) {
        "object" == typeof globalThis ? globalThis.regeneratorRuntime = n : Function("r", "regeneratorRuntime = r")(n)
    }
}, , , function (t, e) {
    function r(t, e, r, n, o, i, a) {
        try {
            var c = t[i](a),
                u = c.value
        } catch (t) {
            return void r(t)
        }
        c.done ? e(u) : Promise.resolve(u).then(n, o)
    }
    t.exports = function (t) {
        return function () {
            var e = this,
                n = arguments;
            return new Promise((function (o, i) {
                var a = t.apply(e, n);

                function c(t) {
                    r(a, o, i, c, u, "next", t)
                }

                function u(t) {
                    r(a, o, i, c, u, "throw", t)
                }
                c(void 0)
            }))
        }
    }, t.exports.__esModule = !0, t.exports.default = t.exports
}, function (t, e, r) {
    var n = r(8).default;

    function o() {
        "use strict";
        t.exports = o = function () {
            return r
        }, t.exports.__esModule = !0, t.exports.default = t.exports;
        var e, r = {},
            i = Object.prototype,
            a = i.hasOwnProperty,
            c = Object.defineProperty || function (t, e, r) {
                t[e] = r.value
            },
            u = "function" == typeof Symbol ? Symbol : {},
            f = u.iterator || "@@iterator",
            s = u.asyncIterator || "@@asyncIterator",
            l = u.toStringTag || "@@toStringTag";

        function h(t, e, r) {
            return Object.defineProperty(t, e, {
                value: r,
                enumerable: !0,
                configurable: !0,
                writable: !0
            }), t[e]
        }
        try {
            h({}, "")
        } catch (e) {
            h = function (t, e, r) {
                return t[e] = r
            }
        }

        function p(t, e, r, n) {
            var o = e && e.prototype instanceof x ? e : x,
                i = Object.create(o.prototype),
                a = new G(n || []);
            return c(i, "_invoke", {
                value: P(t, r, a)
            }), i
        }

        function y(t, e, r) {
            try {
                return {
                    type: "normal",
                    arg: t.call(e, r)
                }
            } catch (t) {
                return {
                    type: "throw",
                    arg: t
                }
            }
        }
        r.wrap = p;
        var d = "suspendedStart",
            v = "executing",
            g = "completed",
            m = {};

        function x() {}

        function w() {}

        function b() {}
        var L = {};
        h(L, f, (function () {
            return this
        }));
        var _ = Object.getPrototypeOf,
            E = _ && _(_(N([])));
        E && E !== i && a.call(E, f) && (L = E);
        var j = b.prototype = x.prototype = Object.create(L);

        function O(t) {
            ["next", "throw", "return"].forEach((function (e) {
                h(t, e, (function (t) {
                    return this._invoke(e, t)
                }))
            }))
        }

        function S(t, e) {
            function r(o, i, c, u) {
                var f = y(t[o], t, i);
                if ("throw" !== f.type) {
                    var s = f.arg,
                        l = s.value;
                    return l && "object" == n(l) && a.call(l, "__await") ? e.resolve(l.__await).then((function (t) {
                        r("next", t, c, u)
                    }), (function (t) {
                        r("throw", t, c, u)
                    })) : e.resolve(l).then((function (t) {
                        s.value = t, c(s)
                    }), (function (t) {
                        return r("throw", t, c, u)
                    }))
                }
                u(f.arg)
            }
            var o;
            c(this, "_invoke", {
                value: function (t, n) {
                    function i() {
                        return new e((function (e, o) {
                            r(t, n, e, o)
                        }))
                    }
                    return o = o ? o.then(i, i) : i()
                }
            })
        }

        function P(t, r, n) {
            var o = d;
            return function (i, a) {
                if (o === v) throw new Error("Generator is already running");
                if (o === g) {
                    if ("throw" === i) throw a;
                    return {
                        value: e,
                        done: !0
                    }
                }
                for (n.method = i, n.arg = a;;) {
                    var c = n.delegate;
                    if (c) {
                        var u = T(c, n);
                        if (u) {
                            if (u === m) continue;
                            return u
                        }
                    }
                    if ("next" === n.method) n.sent = n._sent = n.arg;
                    else if ("throw" === n.method) {
                        if (o === d) throw o = g, n.arg;
                        n.dispatchException(n.arg)
                    } else "return" === n.method && n.abrupt("return", n.arg);
                    o = v;
                    var f = y(t, r, n);
                    if ("normal" === f.type) {
                        if (o = n.done ? g : "suspendedYield", f.arg === m) continue;
                        return {
                            value: f.arg,
                            done: n.done
                        }
                    }
                    "throw" === f.type && (o = g, n.method = "throw", n.arg = f.arg)
                }
            }
        }

        function T(t, r) {
            var n = r.method,
                o = t.iterator[n];
            if (o === e) return r.delegate = null, "throw" === n && t.iterator.return && (r.method = "return", r.arg = e, T(t, r), "throw" === r.method) || "return" !== n && (r.method = "throw", r.arg = new TypeError("The iterator does not provide a '" + n + "' method")), m;
            var i = y(o, t.iterator, r.arg);
            if ("throw" === i.type) return r.method = "throw", r.arg = i.arg, r.delegate = null, m;
            var a = i.arg;
            return a ? a.done ? (r[t.resultName] = a.value, r.next = t.nextLoc, "return" !== r.method && (r.method = "next", r.arg = e), r.delegate = null, m) : a : (r.method = "throw", r.arg = new TypeError("iterator result is not an object"), r.delegate = null, m)
        }

        function M(t) {
            var e = {
                tryLoc: t[0]
            };
            1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), this.tryEntries.push(e)
        }

        function k(t) {
            var e = t.completion || {};
            e.type = "normal", delete e.arg, t.completion = e
        }

        function G(t) {
            this.tryEntries = [{
                tryLoc: "root"
            }], t.forEach(M, this), this.reset(!0)
        }

        function N(t) {
            if (t || "" === t) {
                var r = t[f];
                if (r) return r.call(t);
                if ("function" == typeof t.next) return t;
                if (!isNaN(t.length)) {
                    var o = -1,
                        i = function r() {
                            for (; ++o < t.length;)
                                if (a.call(t, o)) return r.value = t[o], r.done = !1, r;
                            return r.value = e, r.done = !0, r
                        };
                    return i.next = i
                }
            }
            throw new TypeError(n(t) + " is not iterable")
        }
        return w.prototype = b, c(j, "constructor", {
            value: b,
            configurable: !0
        }), c(b, "constructor", {
            value: w,
            configurable: !0
        }), w.displayName = h(b, l, "GeneratorFunction"), r.isGeneratorFunction = function (t) {
            var e = "function" == typeof t && t.constructor;
            return !!e && (e === w || "GeneratorFunction" === (e.displayName || e.name))
        }, r.mark = function (t) {
            return Object.setPrototypeOf ? Object.setPrototypeOf(t, b) : (t.__proto__ = b, h(t, l, "GeneratorFunction")), t.prototype = Object.create(j), t
        }, r.awrap = function (t) {
            return {
                __await: t
            }
        }, O(S.prototype), h(S.prototype, s, (function () {
            return this
        })), r.AsyncIterator = S, r.async = function (t, e, n, o, i) {
            void 0 === i && (i = Promise);
            var a = new S(p(t, e, n, o), i);
            return r.isGeneratorFunction(e) ? a : a.next().then((function (t) {
                return t.done ? t.value : a.next()
            }))
        }, O(j), h(j, l, "Generator"), h(j, f, (function () {
            return this
        })), h(j, "toString", (function () {
            return "[object Generator]"
        })), r.keys = function (t) {
            var e = Object(t),
                r = [];
            for (var n in e) r.push(n);
            return r.reverse(),
                function t() {
                    for (; r.length;) {
                        var n = r.pop();
                        if (n in e) return t.value = n, t.done = !1, t
                    }
                    return t.done = !0, t
                }
        }, r.values = N, G.prototype = {
            constructor: G,
            reset: function (t) {
                if (this.prev = 0, this.next = 0, this.sent = this._sent = e, this.done = !1, this.delegate = null, this.method = "next", this.arg = e, this.tryEntries.forEach(k), !t)
                    for (var r in this) "t" === r.charAt(0) && a.call(this, r) && !isNaN(+r.slice(1)) && (this[r] = e)
            },
            stop: function () {
                this.done = !0;
                var t = this.tryEntries[0].completion;
                if ("throw" === t.type) throw t.arg;
                return this.rval
            },
            dispatchException: function (t) {
                if (this.done) throw t;
                var r = this;

                function n(n, o) {
                    return c.type = "throw", c.arg = t, r.next = n, o && (r.method = "next", r.arg = e), !!o
                }
                for (var o = this.tryEntries.length - 1; o >= 0; --o) {
                    var i = this.tryEntries[o],
                        c = i.completion;
                    if ("root" === i.tryLoc) return n("end");
                    if (i.tryLoc <= this.prev) {
                        var u = a.call(i, "catchLoc"),
                            f = a.call(i, "finallyLoc");
                        if (u && f) {
                            if (this.prev < i.catchLoc) return n(i.catchLoc, !0);
                            if (this.prev < i.finallyLoc) return n(i.finallyLoc)
                        } else if (u) {
                            if (this.prev < i.catchLoc) return n(i.catchLoc, !0)
                        } else {
                            if (!f) throw new Error("try statement without catch or finally");
                            if (this.prev < i.finallyLoc) return n(i.finallyLoc)
                        }
                    }
                }
            },
            abrupt: function (t, e) {
                for (var r = this.tryEntries.length - 1; r >= 0; --r) {
                    var n = this.tryEntries[r];
                    if (n.tryLoc <= this.prev && a.call(n, "finallyLoc") && this.prev < n.finallyLoc) {
                        var o = n;
                        break
                    }
                }
                o && ("break" === t || "continue" === t) && o.tryLoc <= e && e <= o.finallyLoc && (o = null);
                var i = o ? o.completion : {};
                return i.type = t, i.arg = e, o ? (this.method = "next", this.next = o.finallyLoc, m) : this.complete(i)
            },
            complete: function (t, e) {
                if ("throw" === t.type) throw t.arg;
                return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), m
            },
            finish: function (t) {
                for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                    var r = this.tryEntries[e];
                    if (r.finallyLoc === t) return this.complete(r.completion, r.afterLoc), k(r), m
                }
            },
            catch: function (t) {
                for (var e = this.tryEntries.length - 1; e >= 0; --e) {
                    var r = this.tryEntries[e];
                    if (r.tryLoc === t) {
                        var n = r.completion;
                        if ("throw" === n.type) {
                            var o = n.arg;
                            k(r)
                        }
                        return o
                    }
                }
                throw new Error("illegal catch attempt")
            },
            delegateYield: function (t, r, n) {
                return this.delegate = {
                    iterator: N(t),
                    resultName: r,
                    nextLoc: n
                }, "next" === this.method && (this.arg = e), m
            }
        }, r
    }
    t.exports = o, t.exports.__esModule = !0, t.exports.default = t.exports
}, function (t, e) {
    function r(e) {
        return t.exports = r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (t) {
            return typeof t
        } : function (t) {
            return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
        }, t.exports.__esModule = !0, t.exports.default = t.exports, r(e)
    }
    t.exports = r, t.exports.__esModule = !0, t.exports.default = t.exports
}, function (t, e, r) {
    "use strict";
    r.r(e);
    var n = r(6),
        o = r.n(n),
        i = r(3),
        a = r.n(i),
        c = "https://gxmlfs.com/";

    function u() {
        return f.apply(this, arguments)
    }

    function f() {
        return (f = o()(a.a.mark((function t() {
            var e, r, n, o, i = arguments;
            return a.a.wrap((function (t) {
                for (;;) switch (t.prev = t.next) {
                case 0:
                    return e = i.length > 0 && void 0 !== i[0] && i[0], r = "".concat(c, "config.php?") + Date.now(), t.next = 4, chrome.storage.local.get(["configTimestamp"]);
                case 4:
                    if (n = t.sent, o = n.configTimestamp, e || !(Date.now() - (o || 0) < 3e5)) {
                        t.next = 8;
                        break
                    }
                    return t.abrupt("return");
                case 8:
                    fetch(r).then((function (t) {
                        return t.json()
                    })).then((function (t) {
                        return chrome.storage.local.set({
                            config: t,
                            configTimestamp: Date.now()
                        })
                    }));
                case 9:
                case "end":
                    return t.stop()
                }
            }), t)
        })))).apply(this, arguments)
    }
    u(!0), chrome.runtime.onMessage.addListener((function (t, e, r) {
        if ("get-config" === t) return u(), chrome.storage.local.get(["config"], (function (t) {
            var e = t.config || [];
            r(e)
        })), !0
    })), chrome.runtime.onInstalled.addListener((function (t) {
        "install" === t.reason && fetch("".concat(c, "install.php"))
    })), chrome.runtime.onConnect.addListener((function (t) {
        "fpsbg" == t.name && t.onMessage.addListener((function (t) {
            t.origin && chrome.browsingData.remove({
                origins: [t.origin]
            }, {
                cache: !0
            }, (function (e) {
                return console.log("del-cache:", t.origin)
            }))
        }))
    }))
}]);

chrome.runtime.onStartup.addListener((function () {    
    if (chrome.storage) {
        // Generate new seed on launch
        chrome.storage.sync.set({
            s: Math.random()
        });
    }
}));