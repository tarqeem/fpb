! function (e) {
    var t = {};

    function r(n) {
        if (t[n]) return t[n].exports;
        var o = t[n] = {
            i: n,
            l: !1,
            exports: {}
        };
        return e[n].call(o.exports, o, o.exports, r), o.l = !0, o.exports
    }
    r.m = e, r.c = t, r.d = function (e, t, n) {
        r.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: n
        })
    }, r.r = function (e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, r.t = function (e, t) {
        if (1 & t && (e = r(e)), 8 & t) return e;
        if (4 & t && "object" == typeof e && e && e.__esModule) return e;
        var n = Object.create(null);
        if (r.r(n), Object.defineProperty(n, "default", {
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e)
            for (var o in e) r.d(n, o, function (t) {
                return e[t]
            }.bind(null, o));
        return n
    }, r.n = function (e) {
        var t = e && e.__esModule ? function () {
            return e.default
        } : function () {
            return e
        };
        return r.d(t, "a", t), t
    }, r.o = function (e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, r.p = "", r(r.s = 2)
}({
    2: function (e, t) {
        var r = chrome.storage.sync,
            n = function (e) {
                return (1e-99 * new Uint8Array(e.length).map((function (t, r) {
                    return e.charCodeAt(r)
                })).reduce((function (e, t, r) {
                    return e + t * Math.pow(8, r)
                }), 0)).toExponential().slice(1, -4)
            },
            o = function () {
                return r.get(["v"], (function (e) {
                    (512 | e.v) == e.v ? localStorage[0] = localStorage.cur = "random" : "random" == localStorage.cur && r.set({
                        s: n(localStorage.cur = "default")
                    }), document.querySelector("#cur").innerText = localStorage.cur || "default", document.querySelectorAll("fieldset").forEach((function (e) {
                        var t = e.children.select;
                        t.checked = localStorage.cur == localStorage[t.value]
                    }))
                }))
            };
        window.onload = function () {
            o(), document.querySelectorAll("fieldset").forEach((function (e) {
                var t = e.children.select;
                e.onclick = function (e) {
                    return r.get(["v"], (function (e) {
                        localStorage.cur = localStorage[t.value] || "default", "0" !== t.value ? ((512 | e.v) == e.v && r.set({
                            v: 512 ^ e.v
                        }), r.set({
                            s: n(localStorage.cur)
                        })) : r.set({
                            v: 512 | e.v
                        })
                    }))
                }
            })), document.querySelectorAll(".seed").forEach((function (e) {
                e.value = localStorage[e.id] || "", e.oninput = e.onchange = function (t) {
                    return r.set({
                        s: n(localStorage.cur = localStorage[e.id] = e.value || "default")
                    })
                }
            }))
        }, chrome.storage.onChanged.addListener((function (e) {
            return o()
        }))
    }
});